#include<stdio.h>
int main()
{
	int n;
	printf("Please input the length of the array: ");
	scanf("%d",&n);
	int A[n];
	int i,j,temp;
	printf("Please input the array: \n");
	for(i=0;i<n;i++)
		scanf("%d",&A[i]);
	
	for(i=1;i<n;i++)
	{
		j=i-1;
		temp = A[i];
		while(temp<A[j]&&j>=0)
		{
			A[j+1] = A[j];
			j--;			
		}
		A[j+1] = temp;
	}
	
	printf("The ordered array is:\n");
	for(i=0;i<n;i++)
		printf("%d ",A[i]);
	return 0;
}
