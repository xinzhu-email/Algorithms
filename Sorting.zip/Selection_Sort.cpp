#include<stdio.h>
int main()
{
	int n;
	printf("Please input the length of the array: ");
	scanf("%d",&n);
	int A[n];
	int i,j,temp;
	printf("Please input the array: \n");
	for(i=0;i<n;i++)
		scanf("%d",&A[i]);

	for(i=0;i<n;i++)
	{
		for(j=i;j<n;j++)
		{
			if(A[j]<A[i])
			{
				temp = A[j];
				A[j] = A[i];
				A[i] = temp;
			}
		}
	}
	
	printf("The ordered array is:\n");
	for(i=0;i<n;i++)
		printf("%d ",A[i]);
	return 0;
} 
