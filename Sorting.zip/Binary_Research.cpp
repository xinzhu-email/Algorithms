#include<stdio.h> 
int Binary_Research(int A[],int length,int x)
{
	int low,high,mid;
	low = 0;
	high = length;
	while(1)
	{
		mid = (low+high)/2;
		if(low>high)
			return 0;
		if(A[mid]==x)
			return mid+1;
		else if(A[mid]<x)
			low = mid+1;
		else
			high = mid-1;
	}	
}

int main()
{
	int length;
	printf("Please input the length of the nondecreasing ordered array: ");
	scanf("%d",&length);
	int A[length];
	int i;
	printf("Please input the nondecreasing ordered array: \n");
	for(i=0;i<length;i++)
		scanf("%d",&A[i]);
	int x;
	printf("Please input the number you want to research:");
	scanf("%d",&x);
	printf("%d",Binary_Research(A,length,x));
	return 0;
}
